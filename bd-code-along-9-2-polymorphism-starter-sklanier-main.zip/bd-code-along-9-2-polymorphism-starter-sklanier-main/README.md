# Polymorphism -  Code-Along

This activity will be walked through by your instructor.

**Your participation is critical to your understanding**, so please respond when asked by the instructor and ask any questions you may have immediately.

Please do not be afraid to ask questions.  Chances are very good that others have the same and/or similar questions and are bashful about asking.  They will appreciate your asking the question.

This activity will add code to the PlayingCard application in the *Polymorphism* Guided Project and *Inheritance Code-Along-1*.

We will explore using Polymorphism to make our code more reusable, reliable and easier to understand.

Successful completion will be when application program for teh project achieves the desired result.

## Requirements

- IntelliJ with Java 11
- If you're running the code from your terminal, make sure you have Java 11 installed on your machine (not just in IntelliJ)

## Set Up

- Clone this repo and open it's project folder in IntelliJ.
