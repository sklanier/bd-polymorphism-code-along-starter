package com.frank;

import com.frank.model.*;

import java.util.ArrayList;
import java.util.List;

public class UsePlayingCards {
// This is our application program which will instantiate object and use thier methods to manipulate them
// We know this is the application program because it has the main() method
	public static void main(String[] args) {
		System.out.println("-".repeat(80) + "\n Welcome to our Polymorphism Code-Along! \n" + "-".repeat(80));


		AmericanPlayingCard aUSACard      = new AmericanPlayingCard(AmericanPlayingCard.CardValue.KING, AmericanPlayingCard.CardSuit.SPADE);
		ItalianPlayingCard  anItalianCard = new ItalianPlayingCard(ItalianPlayingCard.CardValue.CAVALLO, ItalianPlayingCard.CardSuit.COINS);
		SwissPlayingCard    aSwissCard    = new SwissPlayingCard(SwissPlayingCard.CardValue.AS, SwissPlayingCard.CardSuit.ROSES);
		UnoCard             anUnoCard     = new UnoCard(UnoCard.CARD_VALUE.WILD_DRAW_FOUR, UnoCard.CARD_COLOR.NONE);

		System.out.println("Process an Arraylist of subclass objects using Polymorphism\n");

        // Define an ArrayList of super class references
		List<PlayingCard> someCards = new ArrayList<PlayingCard>();

		// Add subclass class objects to the super class ArrayList
		someCards.add(aSwissCard);    // its OK to assign a sub class object to a super class reference
		someCards.add(aUSACard);      // its OK to assign a sub class object to a super class reference
		someCards.add(anUnoCard);     // its OK to assign a sub class object to a super class reference
		someCards.add(anItalianCard); // its OK to assign a sub class object to a super class reference

		// Process the elements in the ArrayList using the super class reference
		for(PlayingCard theCard : someCards){
			theCard.showCard();  // use the super class reference to process an element in the ArrayList
			System.out.println("The value of the current card is: " + theCard.getCardValueString());
			System.out.println("=".repeat(80));
		}

		System.out.println("-".repeat(80) + "\nThanks for visiting our Polymorphism Code-Along! \n" + "-".repeat(80));

	}  // End of main()

}  // End of class that holds main()
