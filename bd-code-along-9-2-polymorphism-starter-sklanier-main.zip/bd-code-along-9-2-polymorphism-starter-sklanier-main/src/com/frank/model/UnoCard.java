package com.frank.model;

/********************************************************************************************
 * This class represent a card used in the game UNO
 *
 * an Uno card is a PlayingCard with the following attributes:
 *
 * Values: 0 through 9
 * Action Cards: Wild, Wild Draw Four, Skip, Draw Two and Reverse
 * Colors: red, yellow, green, blue (only values 0 through 9 are associated with colors)
 * Suits: None
 *
 ********************************************************************************************/

public class UnoCard extends PlayingCard {

    public enum CARD_VALUE {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, WILD, WILD_DRAW_FOUR, SKIP, DRAW_TWO, REVERSE}

    public enum CARD_COLOR {RED, YELLOW, GREEN, BLUE, NONE}

    public UnoCard(CARD_VALUE value, CARD_COLOR color) {
        super(value.ordinal(), "NONE", color.toString());  // Call the super class ctor to initialize super class attributes

        // After we have initialized the super class attributes, we need to be sure the color is correct for the value
        switch (value) {
            case WILD:            // If the
            case WILD_DRAW_FOUR:  //    value is
            case SKIP:            //          any one
            case DRAW_TWO:        //              of the
            case REVERSE: {       //                 action cards
                setColor(CARD_COLOR.NONE.toString());  // set the color to NONE
            }
        }
    }

    @Override
    public void showCard() {
       System.out.println(this);
    }

    @Override
    public String toString() {
        return "UnoCard{} " + super.toString();
    }

} // end of UnoCard class

