package com.frank.model;

public class ItalianPlayingCard extends PlayingCard {
	
	private static final CardValue DEFAULTCARDVALUE = CardValue.JOKER;
	private static final CardColor DEFAULTCOLOR     = CardColor.YELLOW;
	private static final CardSuit  DEFAULTSUIT      = CardSuit.JOKER;

	// Making the enum public allows application programs to use the enum as constant too
	public static enum CardColor {  // define words to represent allowable card colors (instead of String)
		YELLOW, BLUE, RED, BLACK                  // These are the only valid values Java will allow
	};
	public static enum CardSuit {          // public is OK since they are constants and cannot be changed
		COINS, CUPS, SWORDS, BATONS, JOKER // static so it can be referenced using the class name. ie. no object required
	};
	public static enum CardValue {  // Using the fact that enums are really integers inside value to name our values
		JOKER, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, UNUSED1, UNUSED2, TEN, FANTE, CAVALLO, RE
    //    0     1    2     3     4      5    6    7       8        9       10    11     12     13
	};

	public ItalianPlayingCard() 
	{
		super(DEFAULTCARDVALUE.ordinal(), DEFAULTSUIT.toString(), DEFAULTCOLOR.toString());
	} 

	public ItalianPlayingCard(CardValue value, CardSuit suit) {
		// subclass is responsible for ensuring the super class is initializied with correct data
		super(value.ordinal(),              // Call super ctor with value passed as a numeric
			  suit.toString(),              // Call super ctor with  suit passed as a String
			  DEFAULTCOLOR.toString());     // Initially set card color to default since we cannot call a method here

		setColor(determineColor(suit));     // reset color to color based on suit

		// Verify value passed is valid, if not set value to default value
		if (value == CardValue.UNUSED1 || value == CardValue.UNUSED2 ) {   // Italian Playing cards have no 8 or 9
			setValue(DEFAULTCARDVALUE.ordinal());
		}
		
	}
	// Return the card color based on the suit
	// method is private so only members of the class can use it - Application cannot call this method
	private String determineColor(CardSuit suit) {
		switch (suit) {
			case COINS: {
				return CardColor.YELLOW.toString();
			}
			case CUPS:  {
				return CardColor.BLUE.toString();
			}
			case SWORDS: {
				return CardColor.RED.toString();
			}
			case BATONS: {
				return CardColor.BLACK.toString();
			}
			default: {
				return DEFAULTCOLOR.toString();
			}
		}
	}

	@Override
	public String toString() {
	    // super. is optional when calling a super class method unless you have overriden the method
		return "ItalianPlayingCard: " 
	          +"Value: "    + getValue()      // call super class method to retrieve value of value attribute
	          +" - Color: " + getColor()      // call super class method to retrieve value of color attribute
			  +" - Suit: "  + super.getSuit() // call super class method to retrieve value is suit attribute
			  +" - super.toString()=" + super.toString() + "\n";  // super, required here as subclass has method with
		                                                          //    the same name.  Also, we are IN the overriden
		                                                          //    so withot super. we would be calling ourselves
		                                                          //    recursively until the system was out of resurces
	}
    // this. reference the object used to invoke the method (this.toString() - this class's toString()
	public void showCard() {
		System.out.println(this.toString());
	}

} // end of ItalianPlayingCard class

